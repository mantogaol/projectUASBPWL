<!DOCTYPE html>
<html>
<head>

	<title>GrabBook</title>
	<link href="icon.png" rel="shortcut icon">
	<link rel="stylesheet" href="style.css">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

</head>
<body>


<div class="container">
	<div class="header">
		<h1 class="judul"> Book Reviews </h1>
		<h6 class="judul1"> by syarahadelas </h6>
<div>=================================================================</div>				
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="hotthisweek.php">Hot This Week</a></li>
<li>
<div class="dropdown">
  <button class="dropbtn"><a>Genre</a></button>
  <div class="dropdown-content">

	<a href="home.php">Comedy</a>
	<a href="home.php">Horror</a>
	<a href="home.php">Fantasi</a>
	<a href="home.php">Romance</a>
  </div>
</div>
</li>
<li><a href="kritikdansaran.php">Kritik dan Saran</a><li>

	
		</ul>
	</div>

<center><div>=================================================================</div></center>
	<center><h2><b>HOT THIS WEEK</b></h2></center>
		 <center><img src="h9.jpg" id="efek" height ="350" width="250"></center>
		
		<div class="content">
		<font face="Calibri">
		<br>
	<p class="penulis">sumber : <a href="#">https://luckty.wordpress.com/2018/01/17/review-dilan-dia-adalah-dilanku-tahun-1990/</a></p>
<h1>Dilan : 1990</h1>		
		<p>Kekuatan cinta tak bisa cukup diandalkan. Untuk bisa mengatakannya, ada kebebasan bicara, tetapi keberanian adalah segalanya. (Pidi Baiq, 1972-2098)

Sebenarnya sudah beli buku ini sejak terbit untuk perpustakaan sekolah, sekitar 2015-an kayaknya. Tapi yang namanya buku perpustakaan sekolah, biasanya saya akan kalah cepat dengan murid. Begitulah nasib saat membaca buku ini. Nggak pernah nganggur di perpus, bahkan kini sampe lecek saking seringnya berpindah tangan dari murid satu ke murid lainnya. Hingga filmnya mau tayang, baru kesampaian baca</p>
<br>
<i>
<p>�Kamu cantik.�<br>

�Makasih.�<br>

�Tapi, aku belum mencintaimu.�<br>

�Enggak tahu kalau sore.� (hlm. 35)<br></p>
<br>
</i>
<p>Saya nggak punya ekspetasi apa-apa soal buku ini. Soalnya terkadang yang digandrungi murid-murid belum tentu satu selera dengan saya. Tapi saya justru tahu banget Pidi Baiq sejak zaman kuliah (anak UNPAD ya pastilah tau lagu Sudah Jangan Ke Jatinangor garapannyanya yang melegeda itu :D). Dan saya sudah follow beliau sejak twitter baru booming dan nggak hanya saya, kayaknya hampir semua followersnya bakal difolbek. Dan lebih amazingnya lagi, kalo lagi ada waktu luang, beliau balesin satu- per satu mention yang masuk. Ya ampuunn..ramah banget. Beda banget ama penulis sebelah yang quotesnya dipake buat caption instagram aja ngamuk-ngamuk. </p>
<br>
<p>
<i>
�Kamu cemburu aku pergi dengan Kang Adi?�<br>

�Ah, cemburu itu hanya untuk orang yang enggak percaya diri.�<br>

�Jadi?�<br>

�Dan sekarang, aku sedang tidak percaya diri.� (hlm. 296)<br></p>
</i>
 <p>Jalan ceritanya sebenarnya klise banget, tentang remaja yang sedang jatuh cinta; yang cewek primadona (terlihat dari banyaknya cowok yang mendekatinya) dan yang cowok anak genk motor. Tapi entah kenapa, saya kok malah menikmati jalan cerita masa lalu Dilan dan Milea saat masih berseragam abu-abu. Meski gombalan Dilan ini kesannya menye-menye, tapi dia orisinal, bukan hasil copasan dari penyair ternama.</p>
<br>
SELAMAT ULANG TAHUN, MILEA.<br>

INI HADIAH UNTUKMU, CUMA TTS.<br>

TAPI SUDAH KUISI SEMUA.<br>

AKU SAYANG KAMU<br>

AKU TIDAK MAU KAMU PUSING<br>

KARENA HARUS MENGISINYA.<br>

DILAN! (hlm. 75)<br>

<p>Dilan selalu memiliki cara yang sulit diduga untuk membuat Milea merasa surprise dan sangat terharu. Apa yang dia lakukan benar-benar istimewa, sesuatu yang berbeda, yang tidak pernah terpikir orang lain. Sesuatu yang selalu berhasil untuk membuat Milea merasa sangat dicintai, merasa sangat dihargai dengan cara istimewa dan dengan cara yang tidak biasa.</p>

<p>Dilan memang selalu membahas yang nggak perlu, seperti membahas nyamuk salah satunya. Tapi rame. Tapi, seru dan selalu berhasil membuat Milea menjadi merasa senang.</p>
<p>Sebenarnya tanpa disadari lewat tokoh Beni (pacar Milea) dan Kang Adi (guru pembimbing belajar Milea), penulis menyelipkan tentang cowok-cowok yang bakal dijauhi cewek. Lewat tokoh Beni yang merupakan pacar Milea ini, cemburuan dan kasar banget ama Milea. Ya, dia pernah melemparkan kata-kata kasar pada Milea. Meski akhirnya minta maaf beribu kali, 
perasaan cewek pasti sudah terlanjur luka jika disebut dengan kata-kata yang tidak pantas. Bukan drama loh ya. Begitu juga dengan Milea. Meski Beni ini keren, anak orang kaya, tapi bagi Milea, cowok tipikal Beni ini bakal dicoret dari listnya. Kemudian ada Kang Adi yang ya ampuunn�tipikal carmuk banget plus seneng banget ngebanggain diri sendiri, dan kadang menjelekkan orang lain. Percayalah, tipikal cowok macam Kang Adi ini meski kuliah di tempat yang paling bergengsi, pintar, mandiri, tapi malah bikin ilfeel cewek, 
termasuk bagi Milea. Ngakak banget pas Dilan ama Mila mengibaratkan Kang Adi ini adalah yang monyet yangs sering mampir ke rumah Milea. </p>

<b><p>Berikut ini adalah tampilan triler dari buku Dilan: 1990</p></b>
		<video center width="600" height="450" controls>
  <source src="vdilan.mp4" type="video/mp4">

</video>

	</div>
	<br>
	<br>
		<div class="footer">
	<p class="copy">Copyright &copy 2018. Syarah Adela Shandi.</p>
	</div>
	</body>
</html>